(function (PV){
	"use strict";

	var def = {
		typeName: "", 
		init: init 
	} 

	function init(scope) {

	}

	PV.toolCatalog.register(def); 

})(window.PIVisualization)
